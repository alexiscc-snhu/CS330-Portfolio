///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// Manage the loading and rendering of 3D scenes
//
// AUTHOR: Alexis Cordero
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <string>

namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width, height, colorChannels;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    if (image)
    {
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        return true;
    }

    return false;
}

void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glDeleteTextures(1, &m_textureIDs[i].ID);
    }
}

int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag == tag)
            return i;
    }

    return -1;
}

void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 modelView =
        glm::translate(positionXYZ) *
        glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f)) *
        glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f)) *
        glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f)) *
        glm::scale(scaleXYZ);

    if (m_pShaderManager != NULL)
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    if (m_pShaderManager != NULL)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
    }
}

void SceneManager::SetShaderTexture(std::string textureTag)
{
    int textureID = FindTextureSlot(textureTag);

    if (textureID >= 0 && m_pShaderManager != NULL)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
    }
}

void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager != NULL)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

void SceneManager::SetMaterial(
    glm::vec3 ambientColor,
    float ambientStrength,
    glm::vec3 diffuseColor,
    glm::vec3 specularColor,
    float shininess)
{
    m_pShaderManager->setVec3Value("material.ambientColor", ambientColor);
    m_pShaderManager->setFloatValue("material.ambientStrength", ambientStrength);
    m_pShaderManager->setVec3Value("material.diffuseColor", diffuseColor);
    m_pShaderManager->setVec3Value("material.specularColor", specularColor);
    m_pShaderManager->setFloatValue("material.shininess", shininess);
}

void SceneManager::SetupSceneLights()
{
    m_pShaderManager->setIntValue(g_UseLightingName, true);

    // Main light above and in front of the monitor
    m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(0.0f, 8.0f, 8.0f));
    m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.25f, 0.25f, 0.25f));
    m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.8f, 0.8f, 0.8f));
    m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(1.0f, 1.0f, 1.0f));
    m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
    m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.4f);

    // Secondary fill light so the scene is not too dark
    m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(-5.0f, 5.0f, 5.0f));
    m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.12f, 0.12f, 0.12f));
    m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.35f, 0.35f, 0.35f));
    m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.4f, 0.4f, 0.4f));
    m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
    m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.2f);

    // Turn off unused lights
    for (int i = 2; i < 4; i++)
    {
        std::string lightIndex = "lightSources[" + std::to_string(i) + "]";
        m_pShaderManager->setVec3Value((lightIndex + ".position").c_str(), glm::vec3(0.0f));
        m_pShaderManager->setVec3Value((lightIndex + ".ambientColor").c_str(), glm::vec3(0.0f));
        m_pShaderManager->setVec3Value((lightIndex + ".diffuseColor").c_str(), glm::vec3(0.0f));
        m_pShaderManager->setVec3Value((lightIndex + ".specularColor").c_str(), glm::vec3(0.0f));
        m_pShaderManager->setFloatValue((lightIndex + ".focalStrength").c_str(), 1.0f);
        m_pShaderManager->setFloatValue((lightIndex + ".specularIntensity").c_str(), 0.0f);
    }
}

void SceneManager::PrepareScene()
{
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadCylinderMesh();

    // Load textures for the desk plane and monitor parts
    CreateGLTexture("../../Utilities/textures/rusticwood.jpg", "wood");
    CreateGLTexture("../../Utilities/textures/stainless.jpg", "metal");

    BindGLTextures();

    // Add lighting for Milestone Five
    SetupSceneLights();
}

void SceneManager::RenderScene()
{
    // FLOOR / DESK PLANE
    SetTransformations(
        glm::vec3(20.0f, 1.0f, 10.0f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 0.0f, 0.0f));

    SetMaterial(
        glm::vec3(0.30f),
        0.30f,
        glm::vec3(0.80f),
        glm::vec3(0.40f),
        0.30f);

    SetShaderTexture("wood");
    SetTextureUVScale(6.0f, 6.0f);
    m_basicMeshes->DrawPlaneMesh();

    // MONITOR BASE
    SetTransformations(
        glm::vec3(2.8f, 0.22f, 1.6f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 0.11f, 0.0f));

    SetMaterial(
        glm::vec3(0.40f),
        0.40f,
        glm::vec3(0.70f),
        glm::vec3(1.0f),
        0.80f);

    SetShaderTexture("metal");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawBoxMesh();

    // MONITOR STAND
    SetTransformations(
        glm::vec3(0.28f, 1.5f, 0.28f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 0.45f, 0.0f));

    SetMaterial(
        glm::vec3(0.40f),
        0.40f,
        glm::vec3(0.70f),
        glm::vec3(1.0f),
        0.80f);

    SetShaderTexture("metal");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // MONITOR SCREEN
    SetTransformations(
        glm::vec3(8.5f, 4.8f, 0.22f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 4.0f, 0.18f));

    SetMaterial(
        glm::vec3(0.15f),
        0.25f,
        glm::vec3(0.25f),
        glm::vec3(0.50f),
        0.50f);

    SetShaderColor(0.08f, 0.08f, 0.10f, 1.0f);
    m_basicMeshes->DrawBoxMesh();
}